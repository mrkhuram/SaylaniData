import React, { Component } from 'react';
import Content from './Content'
class Home extends Component {

  render() {
    
    return (
      <div>
        <Content />
      </div>
    )

  }

}


export default Home